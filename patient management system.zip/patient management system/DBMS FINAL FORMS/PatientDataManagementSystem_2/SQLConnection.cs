﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

using System;
using System.Data.SqlClient;

public class DatabaseManager
{
     public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";

    public DatabaseManager(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public void InsertCustomer(int id, string Name, int age)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "INSERT INTO Customers (FirstName, LastName, Email) VALUES (@FirstName, @LastName, @Email)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@FirstName", id);
            command.Parameters.AddWithValue("@LastName", Name);
            command.Parameters.AddWithValue("@Email", age);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows inserted.");
        }
    }

    public void UpdateCustomerEmail(int customerId, string newEmail)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "UPDATE Customers SET Email = @NewEmail WHERE CustomerId = @CustomerId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@NewEmail", newEmail);
            command.Parameters.AddWithValue("@CustomerId", customerId);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows updated.");
        }
    }

    public void DeleteCustomer(int customerId)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "DELETE FROM Customers WHERE CustomerId = @CustomerId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@CustomerId", customerId);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows deleted.");
        }
    }

    public void GetCustomers()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT * FROM Customers";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                int customerId = reader.GetInt32(0);
                string firstName = reader.GetString(1);
                string lastName = reader.GetString(2);
                string email = reader.GetString(3);
                Console.WriteLine($"Customer ID: {customerId}, Name: {firstName} {lastName}, Email: {email}");
            }

            reader.Close();
        }
    }
}
