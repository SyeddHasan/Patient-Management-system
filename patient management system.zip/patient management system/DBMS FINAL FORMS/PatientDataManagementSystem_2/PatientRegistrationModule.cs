﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class PatientRegistrationModule : Form
    {
        public PatientRegistrationModule()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {




        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Patient patient = new Patient();

            patient.PatientId = int.Parse(textBox1.Text);
            patient.PatientName = textBox5.Text;
            patient.Age = int.Parse(textBox7.Text);
            patient.address = textBox4.Text;
            patient.gender = textBox3.Text;
            patient.PhoneNo = int.Parse(textBox2.Text);
            patient.occupation = textBox10.Text;
            patient.InsuranceNo = int.Parse(textBox6.Text);


            patient.addPatient(patient.PatientId, patient.PatientName, patient.Age, patient.address, patient.gender, patient.PhoneNo, patient.occupation, patient.InsuranceNo);


        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient();

            patient.PatientId = int.Parse(textBox1.Text);
            patient.PatientName = textBox5.Text;
            patient.Age = int.Parse(textBox7.Text);
            patient.address = textBox4.Text;
            patient.gender = textBox3.Text;
            patient.PhoneNo = int.Parse(textBox2.Text);
            patient.occupation = textBox10.Text;
            patient.InsuranceNo = int.Parse(textBox6.Text);


            patient.updatePatient(patient.PatientId, patient.PatientName, patient.Age, patient.address, patient.gender, patient.PhoneNo, patient.occupation, patient.InsuranceNo);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient();

            patient.PatientId = int.Parse(textBox1.Text);

            patient.deletePatient(patient.PatientId);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient();

            patient.PatientId = int.Parse(textBox1.Text);
            patient.readData(patient.PatientId);

            textBox5.Text = patient.PatientName.ToString();
            textBox7.Text = patient.Age.ToString();
            textBox4.Text = patient.address.ToString();
            textBox3.Text = patient.gender.ToString();
            textBox2.Text = patient.PhoneNo.ToString();
            textBox10.Text = patient.occupation.ToString();
            textBox6.Text = patient.InsuranceNo.ToString();

        }
    }
}
