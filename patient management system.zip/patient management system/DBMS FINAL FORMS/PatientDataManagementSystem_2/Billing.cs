﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PatientDataManagementSystem_2
{
    public class Billing
    {
        private int billingId;  //primarykey
        //private int b_PatientId;
        //private String b_PatientName;
       // private int b_Age;
        private String b_Status;
        private int b_Amount;
        //private int b_PhoneNo;
        private string b_Date;


        public Billing() { }

        public Billing(int billingid,String billStatus, int amount, string date)
        {
            this.billingId = billingid;
            this.b_Status = billStatus;
            this.b_Amount = amount;
            this.b_Date = date;
           
        }


        public int BillingBillId
        {
            get { return billingId; }
            set { billingId = value; }
        }
     


        public string BillStatus
        {
            get { return b_Status; }
            set {  b_Status= value; }
        }

        public int BillingAmount
        {
            get { return b_Amount; }
            set { b_Amount = value; }
        }


        public string BillingDate
        {
            get { return b_Date; }
            set { b_Date = value; }
        }


        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



        public void addPatientBill(int billingid, String billStatus, int amount, string date)
        {

            SqlConnection connection = new SqlConnection(connectionString);


            connection.Open();
            string query = "INSERT INTO Billing (Bill_Id,Bill_Status,Bill_Amount,Bill_Date) VALUES (@billingId, @b_Status,@b_Amount,@b_Date)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@BillingId", billingId);
            command.Parameters.AddWithValue("@b_Status",b_Status);
            command.Parameters.AddWithValue("@b_Amount",b_Amount );
            command.Parameters.AddWithValue("@b_Date", b_Date);
           


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows inserted.");
            connection.Close();

            MessageBox.Show("Successfully Inserted!", " Message");
        }

        public void updatePatient(int billingid, String billStatus, int amount, string date)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "UPDATE Billing SET  , Bill_Status =@b_Status, Bill_Amount = @b_Amount  Bill_Date = @b_Date WHERE Bill_Id = @billingId ";
            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@b_Status", b_Status);
            command.Parameters.AddWithValue("@b_Amount", b_Amount);
            command.Parameters.AddWithValue("@b_Date", b_Date);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows updated.");

            MessageBox.Show("Successfully Updated!", " Message");


        }


        public void deleteBill(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = "DELETE FROM Billing WHERE Bill_Id = @Id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows deleted.");

            MessageBox.Show("Successfully Deleted!", " Message");


        }

        public void readData(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "SELECT * FROM Billing  WHERE Bill_Id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                billingId = reader.GetInt32(0);
                b_Amount = reader.GetInt32(1);
                b_Status = reader.GetString(3);
                b_Date = reader.GetString(2); 


            }

            reader.Close();


            MessageBox.Show("Data Found!", " Message");

        }


    }

}
