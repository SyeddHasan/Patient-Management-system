﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDataManagementSystem_2
{
    public class Appointment
    {
        private int a_PatientId;
        private int a_AppointmentId;
        private String a_PatientName;
        private int a_Age;
        private String a_Address;
        private String a_Gender;
        private int a_PhoneNo;
        private string a_DoctorName;
        private string a_Date;
        private string a_Time;


        public Appointment() { }

        public Appointment(int P_id,int AId , String name, int age, 
            String Gender, int phoneNo, string DrName,string date,string time)

        {
            this.a_PatientId = P_id;
            this.a_AppointmentId= AId;
            this.a_PatientName = name;
            this.a_Age = age;
            this.a_Gender = Gender;
            this.a_PhoneNo = phoneNo;
            this.a_DoctorName =DrName;
            this.a_Date=date;
            this.a_Time = time;
        }


       public int AppointmentId
        {
            get { return a_AppointmentId; }
            set { a_AppointmentId = value; }

        }
        public int PatientId
        {
            get { return a_PatientId; }
            set { a_PatientId = value; }
        }

        public String PatientName
        {
            get { return a_PatientName; }
            set { a_PatientName = value; }
        }
        public int age
        {
            get { return a_Age; }
            set { a_Age = value; }

        }
       

        public string gender
        {
            get { return a_Gender; }
            set { a_Gender = value; }
        }

        

        public int Phone
        {
            get { return a_PhoneNo; }
            set { a_PhoneNo = value; }
        }

        public string DoctorName
        {
            get { return a_DoctorName ; }
            set { a_DoctorName= value; }
        }

        public string date
        {
            get { return a_Date; }
            set { a_Date = value; }
        }
        public string time
        {
            get { return a_Time; }
            set { a_Time = value; }

        }








        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



        public void addPatientAppointment(int AId,int p_Id, 
            string name, int age, string gender, int phoneNo, string doctorName, string date, string time)
        {

            SqlConnection connection = new SqlConnection(connectionString);


            connection.Open();
            string query = "INSERT INTO Appointments (App_Id, Patient_Id,Patient_Name,Age,Gender,Phone_No,Doctor_Name,App_Date,Time_Slot)" +
                " VALUES (@P_id,@AId , @name, @age, @Gender, @phoneNo, @DrName,@date,@time)";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@P_id", AId);
            command.Parameters.AddWithValue("@AId", p_Id);
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@age",age);
           // command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@Gender", gender);
            command.Parameters.AddWithValue("@phoneNo", phoneNo);
            command.Parameters.AddWithValue("@DrName", doctorName);
            command.Parameters.AddWithValue("@date", date);
            command.Parameters.AddWithValue("time", time);


            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows inserted.");
            connection.Close();

            MessageBox.Show("Successfully Inserted!", " Message");
        }

        public void updateAppointment(int AId, int p_Id,
            string name, int age, string gender, int phoneNo, string doctorName, string date, string time)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "UPDATE Appointments SET Patient_Name = @name , Age = @age , Gender=@gender,Phone_No=@phoneNo,DoctorName=@doctorname,App_Date=@date,Time_Slot=@time WHERE  App_Id= @id ";
            SqlCommand command = new SqlCommand(query, connection);
            
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@age", age);
            //command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@phoneNo", phoneNo);
            command.Parameters.AddWithValue("@doctorname", doctorName);
            command.Parameters.AddWithValue("@date", date);
            command.Parameters.AddWithValue("@time", time);

            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows updated.");

            MessageBox.Show("Successfully Updated!", " Message");


        }


        public void deletePatient(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string query = "DELETE FROM Appointments WHERE App_Id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            int rowsAffected = command.ExecuteNonQuery();
            Console.WriteLine($"{rowsAffected} rows deleted.");

            MessageBox.Show("Successfully Deleted!", " Message");


        }

        public void readData(int id)
        {
            SqlConnection connection = new SqlConnection(connectionString);

            connection.Open();
            string query = "SELECT * FROM Appointments  WHERE App_Id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                a_AppointmentId = reader.GetInt32(0);
                a_PatientId = reader.GetInt32(1);
                PatientName = reader.GetString(2);
                a_Age = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);
                a_Gender = reader.GetString(4);
                a_PhoneNo = reader.GetInt32(5);
                a_DoctorName= reader.GetString(6);
                a_Date=reader.GetString(7);
                a_Time=reader.GetString(8);
            }

            reader.Close();


            MessageBox.Show("Data Found!", " Message");

        }



    }




}
