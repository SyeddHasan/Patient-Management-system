﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class Ward_Info : Form
    {
        public Ward_Info()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WardInfo ward = new WardInfo();

            ward.WardNo = int.Parse(textBox1.Text);
            ward.chargeperday = int.Parse(textBox4.Text);
            ward.bedcapacity = int.Parse(textBox2.Text);
            ward.wardname = textBox7.Text;
            ward.wardtype= textBox3.Text;


            ward.addWardInfo(ward.WardNo, ward.chargeperday, ward.bedcapacity,ward.wardname, ward.wardtype);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WardInfo ward= new WardInfo();

            ward.WardNo = int.Parse(textBox1.Text);
            ward.chargeperday = int.Parse(textBox4.Text);
            ward.bedcapacity = int.Parse(textBox2.Text);
            ward.wardname = textBox7.Text;
            ward.wardtype = textBox3.Text;


            ward.updateWardInfo(ward.WardNo, ward.chargeperday, ward.bedcapacity, ward.wardname,ward.wardtype);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WardInfo ward = new WardInfo();


            ward.WardNo = int.Parse(textBox1.Text);
            ward.readDataWard(ward.WardNo);

            textBox1.Text = ward.WardNo.ToString();
            textBox2.Text = ward.bedcapacity.ToString();
            textBox7.Text = ward.wardname.ToString();
            textBox3.Text = ward.wardtype.ToString();
            textBox4.Text = ward.chargeperday.ToString();
        }
    }
}
