﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDataManagementSystem_2
{
    internal class PatientRegistration
    {




        public PatientRegistration() { }
    }
}
