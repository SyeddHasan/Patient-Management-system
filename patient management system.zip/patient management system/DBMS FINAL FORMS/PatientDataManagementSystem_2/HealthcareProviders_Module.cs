﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class HealthcareProviders_Module : Form
    {
        public HealthcareProviders_Module()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            HealthCareProvider hcp = new HealthCareProvider();

            hcp.DoctorId = int.Parse(textBox1.Text);
            hcp.DoctorName = textBox5.Text;
            hcp.Title = textBox10.Text;
            hcp.Age = int.Parse(textBox2.Text);
            hcp.Department = textBox6.Text;
            hcp.Education = textBox4.Text;
            hcp.MedicalDegree = textBox3.Text;
            hcp.PhoneNo = int.Parse(textBox7.Text);



            hcp.AddDoctor(hcp.DoctorId, hcp.DoctorName, hcp.Title, hcp.Age, hcp.Department, hcp.Education, hcp.MedicalDegree, hcp.PhoneNo);

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            HealthCareProvider hcp = new HealthCareProvider();
            hcp.DoctorId = int.Parse(textBox1.Text);
            hcp.DoctorName = textBox5.Text;
            hcp.Title = textBox10.Text;
            hcp.Age = int.Parse(textBox2.Text);
            hcp.Department = textBox6.Text;
            hcp.Education = textBox4.Text;
            hcp.MedicalDegree = textBox3.Text;
            hcp.PhoneNo = int.Parse(textBox7.Text);



            hcp.updateDoctor(hcp.DoctorId, hcp.DoctorName, hcp.Title, hcp.Age, hcp.Department, hcp.Education, hcp.MedicalDegree, hcp.PhoneNo);

        }

        private void button3_Click(object sender, EventArgs e)
        {

            HealthCareProvider hcp = new HealthCareProvider();

            hcp.DoctorId = int.Parse(textBox1.Text);

            hcp.deleteDoctor(hcp.DoctorId);

        }

        private void button4_Click(object sender, EventArgs e)
        {

            HealthCareProvider hcp = new HealthCareProvider();
            hcp.DoctorId= int.Parse(textBox1.Text);
            hcp.readData(hcp.DoctorId);

            textBox5.Text =hcp.DoctorName.ToString();
            textBox6.Text =hcp.Department.ToString();
            textBox10.Text = hcp.Title.ToString();
            textBox2.Text = hcp.Age.ToString();
            textBox4.Text =hcp.Education.ToString();
            textBox3.Text =hcp.MedicalDegree.ToString();
            textBox7.Text =hcp.PhoneNo.ToString();
           

        }
    }
}
