﻿using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net;

public class PatientWard
{
    private int wardNo;
    private int patientId;
    private string admitDate;
    private string dischargeDate;

    public PatientWard() { }

    public PatientWard(int wardno, int pat_id,string ad,string dd)
    {
        this.wardNo = wardno;
        this.patientId = pat_id;
        this.admitDate = ad;
        this.dischargeDate = dd;

    }



    public int PatientId
    {
        get { return patientId; }
        set { patientId = value; }
    }

    public int WardNo
    {
        get { return wardNo; }
        set { wardNo = value; }
    }
    public string AdmitDate
    {
        get { return admitDate; }
        set { admitDate = value; }  

    }
    public string DischargeDate
    {
        get { return dischargeDate; }
        set { dischargeDate = value; }
    }







    public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



    public void addPatientWard(int wardno, int patid,string ad,string dd)
    {

        SqlConnection connection = new SqlConnection(connectionString);


        connection.Open();
        string query = "INSERT INTO Patient (Ward_No,Patient_Id,AdmissionDate,DischargeDate) VALUES (@wardno, @patid,@ad,@dd)";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@wardno", wardno);
        command.Parameters.AddWithValue("@patid", patid);
        command.Parameters.AddWithValue("@ad", ad);
        command.Parameters.AddWithValue("@dd", dd);


        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows inserted.");
        connection.Close();

        MessageBox.Show("Successfully Inserted!", " Message");
    }


    public void updatePatientWard(int wardno, int patid, string ad, string dd)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "UPDATE Patient SET Ward_No=@wardno, Patient_Id = @patid,AdmissionDate=@ad,DischargeDate=@dd WHERE Patient_Id = @patid ";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@wardno", wardno);
        command.Parameters.AddWithValue("@patid", patid);
        command.Parameters.AddWithValue("@ad", ad);
        command.Parameters.AddWithValue("@dd", dd);




        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows updated.");

        MessageBox.Show("Successfully Updated!", " Message");


    }

    public void deletePatientWard(int Patid)
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        string query = "DELETE FROM Patient WHERE Patient_Id = @id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id",Patid );
        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows deleted.");

        MessageBox.Show("Successfully Deleted!", " Message");


    }


    public void readDataWard(int patid)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "SELECT * FROM Patient  WHERE Patient_Id = @id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", patid);
        SqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
            PatientId = reader.GetInt32(7);
            wardNo = reader.GetInt32(1);
            admitDate = reader.GetString(2);
            dischargeDate = reader.GetString(3);
        }

        reader.Close();


        MessageBox.Show("Data Found!", " Message");

    }






}
