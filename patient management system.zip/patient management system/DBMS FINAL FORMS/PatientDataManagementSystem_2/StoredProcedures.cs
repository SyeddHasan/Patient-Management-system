﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatientDataManagementSystem_2
{
    public partial class StoredProcedures : Form
    {
        public StoredProcedures()
        {
            InitializeComponent();
        }



        public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";


        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            String Query = "Exec spDoctorsJobTitle";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(Query, connection);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);

            dataGridView1.DataSource = dataTable;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            String Query = "Exec dbo.GetPatientStatisticsByDepartment";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(Query, connection);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);

            dataGridView2.DataSource = dataTable;
        }

    }
}
