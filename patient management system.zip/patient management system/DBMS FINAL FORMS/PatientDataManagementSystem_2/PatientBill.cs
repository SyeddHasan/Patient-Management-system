﻿using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Net;

public class PatientBill
{
    private int BillId;
    private int patientId;


    public PatientBill() { }

    public PatientBill(int bill_id, int pat_id)
    {
        this.BillId = bill_id;
        this.patientId = pat_id;

    }



    public int PatientId
    {
        get { return patientId; }
        set { patientId = value; }
    }

    public int BillID
    {
        get { return BillId; }
        set { BillId = value; }
    }










    public string connectionString = "Data Source=DESKTOP-174794H;Initial Catalog=PatientInformation;Integrated Security=True";



    public void addPatientBill(int billid, int patid)
    {

        SqlConnection connection = new SqlConnection(connectionString);


        connection.Open();
        string query = "INSERT INTO Patient (Bill_Id,Patient_Id) VALUES (@billid, @patid)";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@billid", billid);
        command.Parameters.AddWithValue("@patid", patid);

        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows inserted.");
        connection.Close();

        MessageBox.Show("Successfully Inserted!", " Message");
    }


    public void updatePatientBill(int billid, int patid)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "UPDATE Patient SET Bill_Id=@billid, Patient_Id = @patid WHERE Patient_Id = @patid ";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@billid", billid);
        command.Parameters.AddWithValue("@patid", patid);




        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows updated.");

        MessageBox.Show("Successfully Updated!", " Message");


    }

    public void deletePatientBill(int billid)
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        string query = "DELETE FROM Patient WHERE Bill_Id = @Id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@Bill_Id", billid);
        int rowsAffected = command.ExecuteNonQuery();
        Console.WriteLine($"{rowsAffected} rows deleted.");

        MessageBox.Show("Successfully Deleted!", " Message");


    }


    public void readDataBill(int patid)
    {
        SqlConnection connection = new SqlConnection(connectionString);

        connection.Open();
        string query = "SELECT * FROM Patient  WHERE Patient_Id = @id";
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@id", patid);
        SqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
            PatientId = reader.GetInt32(1);
            BillID = reader.GetInt32(7);
            
        }

        reader.Close();


        MessageBox.Show("Data Found!", " Message");

    }






}
